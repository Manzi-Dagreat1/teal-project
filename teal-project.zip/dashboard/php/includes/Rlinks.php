<div class="fixed-quick-links">
    <a href="#back" style="background-color: red;" onclick="history.back()">
        <i class="fa-solid fa-arrow-right"></i>
    </a>
    <a href="settings.php" class="differ">
        <i class="fa-solid fa-cogs"></i>
    </a>
    <a href="php/extras/logout.php">
        <i class="fa-solid fa-right-from-bracket"></i>
    </a>
</div>