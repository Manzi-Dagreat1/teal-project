const slashOpen = document.querySelector('.slashOpen');
const slashClose = document.querySelector('.slashClose');
const modalNotify = document.querySelector('.modal-notify');
const defaultBackDrop = document.querySelector('.default-back-drop');

slashOpen.onclick = () => {
    modalNotify.classList.remove('deactivate');
    defaultBackDrop.classList.remove('deactivate');
}

slashClose.onclick = () => {
    modalNotify.classList.add('deactivate');
    defaultBackDrop.classList.add('deactivate');
}


// Click & Copy - Paste/Fill in the input
const option = document.querySelectorAll('#OptOpt');
const inputOptOne = document.querySelector('#inputOptOne');

option.forEach(el => {
    el.addEventListener('click', () => {
        inputOptOne.value = el.value;
    });
});


// Click & Copy - Paste/Fill in the input
const optionTwo = document.querySelectorAll('#OptOptSec');
const inputOptTwo = document.querySelector('#inputOptTwo');

optionTwo.forEach(elTwo => {
    elTwo.addEventListener('click', () => {
        inputOptTwo.value = elTwo.value;
    });
});