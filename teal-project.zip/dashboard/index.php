<?php
include "php/includes/pure_header.php";

$countUsers = mysqli_query($con, "SELECT * FROM `users` WHERE `Role` != 'admin' AND `isDeleted` = 'notDeleted'");
$AllUsers = mysqli_num_rows($countUsers);

if ($AllUsers == 0) {
    $displayUsers = 0;
} else {
    $displayUsers = $AllUsers . '+';
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#007bff">
    <!-- 
        Contents and all features developed in this system.
        Prepared and developed by @Prince Parfait - +(250) 7 9205 4846
        Email Address: ganzaparfait7@gmail.com
     -->
 
    <link rel="stylesheet" href="extensions/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="extensions/bootstrap/js/bootstrap.bundle.min.js">
    <link rel="stylesheet" href="extensions/fontawesome/css/all.css">
    <link rel="stylesheet" href="extensions/Jquery/jquery.dataTables.min.css">
    <link rel="icon" href="assets/images/favicon-32x32.png">
    <link rel="stylesheet" href="assets/css/main.css?v=1.8">
    <link rel="stylesheet" href="assets/css/ess.css?v=1.4">
    <script src="assets/js/chart.js"></script>

    <!-- 
        *****************************************************************

            ___________________________

                All Assets from assets/folder/to/in/this/file...
            ___________________________

        *****************************************************************
      -->
    <title>Gas Station - System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            /* padding: 20px; */
            background: #f5f5f5;
        }

        .chart-container {
            width: 90%;
            margin: 20px auto;
            height: 300px;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        #controls {
            text-align: center;
            margin: 20px;
            display:none;
        }

        button {
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            background: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
        }

        button:hover {
            background: #45a049;
        }

        #lastUpdate {
            text-align: center;
            color: #666;
            margin: 10px;
        }

        .error-message {
            color: #ff0000;
            text-align: center;
            margin: 10px;
            display: none;
        }
    </style>
</head>

<body>
    <div class="body-contents-wrapper">
        <?php include('sidebar.php') ?>

        <div class="asideBarBacDrop"></div>

        <div class="contents">
            <?php include('php/includes/header.php'); ?>

            <div class="cont-container">
                <div class="compare-title">
                    <div class="title-txt firstTitle">
                        <h6>Records Overview</h6>
                    </div>
                    <div class="title-txt secondTitle" style="text-align: left;">
                        <h6>Records Overview</h6>
                    </div>
                </div>

                <!-- Sensor Data Table -->
                <div style="width: 100%; margin: 20px auto;">
                  <table class="table table-bordered" style="background: white;">
                    <thead>
                      <tr>
                        <th>Temperature (°C)</th>
                        <th>Humidity (%)</th>
                        <th>Ammonia (ppm)</th>
                        <th>CO₂ (ppm)</th>
                        <th>Dust (µg/m³)</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td id="temperature">--</td>
                        <td id="humidity">--</td>
                        <td id="ammonia">--</td>
                        <td id="co2">--</td>
                        <td id="dust">--</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <div id="controls">
                    <button id="toggleButton">Stop</button>
                </div>
                <!-- <div id="lastUpdate">Last Updated: Never</div> -->
                <div id="errorMessage" class="error-message"></div>


                <!-- Multi-line Chart for All Sensor Data -->
                <div class="chart-container">
                    <canvas id="sensorChart"></canvas>
                </div>

                <!-- Bar Chart for Latest Sensor Data -->
                <div class="chart-container">
                    <canvas id="latestSensorChart"></canvas>
                </div>


                <?php include('php/includes/Rlinks.php'); ?>

                <?php include('php/includes/footer.php'); ?>
            </div>

        </div>
    </div>

    <div class="default-back-drop deactivate slashClose"></div>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/opt_modal.js"></script> 
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
    <script src="extensions/Jquery/jquery.js"></script>
    <!-- DataTables JavaScript -->
    <script src="extensions/Jquery/jquery.dataTables.min.js"></script>
    <script>

// Store time series data for chart
const sensorHistory = {
    labels: [],
    temperature: [],
    humidity: [],
    ammonia: [],
    co2: [],
    dust: []
};

const MAX_POINTS = 30; // Show last 30 points


const sensorChart = new Chart(document.getElementById('sensorChart'), {
    type: 'line',
    data: {
        labels: sensorHistory.labels,
        datasets: [
            {
                label: 'Temperature (°C)',
                data: sensorHistory.temperature,
                borderColor: 'rgb(255, 99, 132)',
                fill: false,
                tension: 0.1
            },
            {
                label: 'Humidity (%)',
                data: sensorHistory.humidity,
                borderColor: 'rgb(54, 162, 235)',
                fill: false,
                tension: 0.1
            },
            {
                label: 'Ammonia (ppm)',
                data: sensorHistory.ammonia,
                borderColor: 'rgb(255, 206, 86)',
                fill: false,
                tension: 0.1
            },
            {
                label: 'CO₂ (ppm)',
                data: sensorHistory.co2,
                borderColor: 'rgb(75, 192, 192)',
                fill: false,
                tension: 0.1
            },
            {
                label: 'Dust (µg/m³)',
                data: sensorHistory.dust,
                borderColor: 'rgb(153, 102, 255)',
                fill: false,
                tension: 0.1
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: false,
        plugins: {
            legend: { position: 'top' }
        },
        scales: {
            x: { title: { display: true, text: 'Time' } },
            y: { beginAtZero: true }
        }
    }
});

// Bar chart for latest data
const latestSensorChart = new Chart(document.getElementById('latestSensorChart'), {
    type: 'bar',
    data: {
        labels: ['Temperature (°C)', 'Humidity (%)', 'Ammonia (ppm)', 'CO₂ (ppm)', 'Dust (µg/m³)'],
        datasets: [{
            label: 'Latest Sensor Data',
            data: [0, 0, 0, 0, 0],
            backgroundColor: [
                'rgba(255, 99, 132, 0.7)',
                'rgba(54, 162, 235, 0.7)',
                'rgba(255, 206, 86, 0.7)',
                'rgba(75, 192, 192, 0.7)',
                'rgba(153, 102, 255, 0.7)'
            ]
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { display: false }
        },
        scales: {
            y: { beginAtZero: true }
        }
    }
});


// Fetch all data for the chart
async function fetchAllSensorData() {
    try {
        const response = await fetch('./php/getData.php');
        const data = await response.json();
        if (!Array.isArray(data) || data.length === 0) return;

        // Clear chart data
        sensorHistory.labels.length = 0;
        sensorHistory.temperature.length = 0;
        sensorHistory.humidity.length = 0;
        sensorHistory.ammonia.length = 0;
        sensorHistory.co2.length = 0;
        sensorHistory.dust.length = 0;

        // Fill chart data with all records
        data.forEach(row => {
            sensorHistory.labels.push(row.timestamp || '');
            sensorHistory.temperature.push(Number(row.temperature) || 0);
            sensorHistory.humidity.push(Number(row.humidity) || 0);
            sensorHistory.ammonia.push(Number(row.ammonia) || 0);
            sensorHistory.co2.push(Number(row.co2) || 0);
            sensorHistory.dust.push(Number(row.dust) || 0);
        });
        sensorChart.update('none');
    } catch (error) {
        console.error('Error fetching all sensor data:', error);
    }
}


// Fetch only the latest data for the table and bar chart
async function fetchLatestSensorData() {
    try {
        const response = await fetch('./php/get_data.php');
        const data = await response.json();
        if (data.error) return;
        document.getElementById('temperature').textContent = data.temperature !== undefined ? data.temperature : '--';
        document.getElementById('humidity').textContent = data.humidity !== undefined ? data.humidity : '--';
        document.getElementById('ammonia').textContent = data.ammonia !== undefined ? data.ammonia : '--';
        document.getElementById('co2').textContent = data.co2 !== undefined ? data.co2 : '--';
        document.getElementById('dust').textContent = data.dust !== undefined ? data.dust : '--';

        // Update bar chart
        latestSensorChart.data.datasets[0].data = [
            Number(data.temperature) || 0,
            Number(data.humidity) || 0,
            Number(data.ammonia) || 0,
            Number(data.co2) || 0,
            Number(data.dust) || 0
        ];
        latestSensorChart.update('none');
    } catch (error) {
        console.error('Error fetching latest sensor data:', error);
    }
}

setInterval(fetchAllSensorData, 5000);
setInterval(fetchLatestSensorData, 5000);
fetchAllSensorData();
fetchLatestSensorData();
</script>

    <script>
        $(document).ready(function() {
            $('#myTable').DataTable({
                "paging": true, // Enable pagination
                "searching": true, // Enable search/filter box
                "ordering": true, // Enable sorting
                "lengthMenu": [15, 25, 50, 100], // Options for rows per page dropdown
                "info": true // Show table information (e.g., "Showing 1 to 10 of 50 entries")
            });
        });


        const SPEC_CHANNELS = 288;
        const UPDATE_INTERVAL = 5000; // 1 second
        let isActive = true;

        // ...existing code...
    </script>
</body>

</html>