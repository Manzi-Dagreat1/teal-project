<?php
session_start();
include "config.php";

$uname_phone = mysqli_real_escape_string($con, $_POST["uname_phone"]);
$password = mysqli_real_escape_string($con, $_POST["password"]);
$current_time = date('Y-m-d H:i:s');

if (!empty($uname_phone) && !empty($password)) {
    $sql = mysqli_query($con, "SELECT * FROM `users`
    WHERE isDeleted = 'notDeleted' AND `PhoneNumber` = '$uname_phone' OR `Email` = '$uname_phone'");
    $row = mysqli_fetch_assoc($sql);


    if (isset($_COOKIE['Password'])) {
        // If user db password doesn't match with cookie password, ask for his password manually

        if (password_verify($_COOKIE['Password'], $row['Password'])) {
            $password = $_COOKIE['Password'];
        } else {
            $password = mysqli_real_escape_string($con, $_POST["password"]);
            setcookie('PhoneNumber/Email', '', time() - 1, "/"); // Exprire cookie if not checked box
            setcookie('Password', '', time() - 1, "/");
        }
    } else {
        $password = mysqli_real_escape_string($con, $_POST["password"]);
    }


    if (mysqli_num_rows($sql) > 0) {
        // Check if account is locked
        if (!empty($row['lock_until']) && $current_time < $row['lock_until']) {
            $timeRemaining = strtotime($row['lock_until']) - time();
            echo json_encode(['status' => 'locked', 'time_remaining' => $timeRemaining]);
            exit;
        }

        if (password_verify($password, $row['Password'])) {
            // Successful login: reset failed attempts and lock_until
            $reset_sql = mysqli_query($con, "UPDATE users SET `failed_attempts` = '0', `lock_until` = NULL
            WHERE UserId = '{$row['UserId']}'");

            if (isset($_POST['rememberme'])) {
                setcookie('PhoneNumber/Email', $uname_phone, time() + 60 * 60 * 7, "/"); // 7 days or (86400 * 30) 30 days
                setcookie('Password', $password, time() + 3600 * 2, "/"); // 2 hours
            } else {
                setcookie('PhoneNumber/Email', $uname_phone, time() - 10, "/"); // Exprire cookie if not checked box
                setcookie('Password', $password, time() - 10, "/");
            }
            // Change user status to active now if logged in again

            $_SESSION['log_uni_id'] = $row['Unique_id'];

            $u_logged_in_id = $row['UserId'];
            // $user_ip = mysqli_real_escape_string($con, $_SERVER['REMOTE_ADDR']); // Get the user's IP address

            // $ip = mysqli_real_escape_string($con, $_SERVER['REMOTE_ADDR']);
            // $access_key = '20d197e7c12f02';
            // $url = "http://ipinfo.io/{$ip}/json?token={$access_key}";

            // $location_data = file_get_contents($url);
            // $location = json_decode($location_data, true);

            // $provider = isset($location['org']) ? $location['org'] : 'N/A'; // This gives the provider or organization
            // $network_type = isset($location['loc']) ? 'VPN/Generic Tunnel' : 'Normal'; // Assuming you check 'loc' for VPNs

            // $city = mysqli_real_escape_string($con, $location['city']);
            // $region = mysqli_real_escape_string($con, $location['region']);
            // $country = mysqli_real_escape_string($con, $location['country']);
            // $provider = mysqli_real_escape_string($con, $provider);
            // $network_type = mysqli_real_escape_string($con, $network_type);

            // $user_agent = mysqli_real_escape_string($con, $_SERVER['HTTP_USER_AGENT']); // Get the user's device information

            // $report_user_interaction = mysqli_query($con, "INSERT INTO `login_activity`(`UserId`, `IpAddress`, `City`, `Region`, `Country`, `DeviceInfo`, `Provider`, `NetworkType`)
            // VALUES ('$u_logged_in_id','$user_ip','$city','$region','$country','$user_agent', '$provider', '$network_type')");

            // if (!$report_user_interaction) {
            //     echo "false";
            // }

            function isWeakPassword($password)
            {
                // Check if the password is numeric and sequential (e.g., 1234, 5678)
                if (is_numeric($password)) {
                    $isSequential = true;
                    for ($i = 0; $i < strlen($password) - 1; $i++) {
                        if ((int)$password[$i + 1] !== (int)$password[$i] + 1) {
                            $isSequential = false;
                            break;
                        }
                    }
                    if ($isSequential) {
                        return "Weak Password: Numeric sequence detected.";
                    }
                }

                // Check if the password is alphabetic and sequential (e.g., abcd, xyz)
                if (ctype_alpha($password)) {
                    $isSequential = true;
                    $password = strtolower($password); // Normalize to lowercase
                    for ($i = 0; $i < strlen($password) - 1; $i++) {
                        if (ord($password[$i + 1]) !== ord($password[$i]) + 1) {
                            $isSequential = false;
                            break;
                        }
                    }
                    if ($isSequential) {
                        return "Weak Password: Alphabetic sequence detected.";
                    }
                }

                // Check if password is too short
                if (strlen($password) <= 4) {
                    return "Weak Password: Too short.";
                }

                // If none of the conditions match, the password is not considered weak
                return false;
            }

            $result = isWeakPassword($password);
            if ($result) {
                // echo "Password '$password': $result\n";
                $_SESSION['wepassak'] = '0';

                $up_sql = mysqli_query($con, "UPDATE users SET PasswordDetection = '0'
                WHERE `UserId` = '$u_logged_in_id'");

                echo json_encode(["status" => "success"]);
            } else {
                // echo "Password '$password' is strong.\n";
                $_SESSION['wepassak'] = '1';
                echo json_encode(["status" => "success"]);
            }

            // echo "$password";
        } else {
            // Increment failed attempts
            $failed_attempts = $row['failed_attempts'] + 1;

            if ($failed_attempts >= 3) {
                // Lock account for 15 minutes
                $lock_until = date('Y-m-d H:i:s', strtotime('+15 minutes'));
                $lock_sql = mysqli_query($con, "UPDATE users SET failed_attempts = $failed_attempts, 
                    lock_until = '$lock_until' WHERE UserId = '{$row['UserId']}'");

                echo "Your account is locked due to too many failed login attempts. Try again after 15 minutes.";
            } else {
                // Update failed attempts
                $update_attempts_sql = mysqli_query($con, "UPDATE users SET failed_attempts = $failed_attempts 
                    WHERE UserId = '{$row['UserId']}'");

                $remaining_attempts = 3 - $failed_attempts;
                echo json_encode(['status' => "Wrong password. You have $remaining_attempts login attempt(s) left."]);
                exit;
            }
        }
    } else {
        echo json_encode(['status' => 'Incorrect Phone number/Email']);
        exit;
    }
} else {
    echo json_encode(['status' => 'All inputs are required']);
    exit;
}
